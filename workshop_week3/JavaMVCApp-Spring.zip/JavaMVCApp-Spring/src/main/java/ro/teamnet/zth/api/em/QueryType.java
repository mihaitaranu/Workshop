package ro.teamnet.zth.api.em;

public enum QueryType {
    SELECT,
    INSERT,
    UPDATE,
    DELETE
}
