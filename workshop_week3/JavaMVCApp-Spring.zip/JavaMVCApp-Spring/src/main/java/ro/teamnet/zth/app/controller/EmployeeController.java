package ro.teamnet.zth.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import ro.teamnet.zth.app.domain.Employee;
import ro.teamnet.zth.app.service.EmployeeServiceImpl;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by Taranu on 06/05/15.
 */
@Controller()
@RequestMapping(value = "/employees")
public @ResponseBody class EmployeeController {
    @RequestMapping(value = "/all",method = RequestMethod.GET)
    public List<Employee> getAllEmployees() {
        return new EmployeeServiceImpl().findAllEmployees();
    }
    @RequestMapping(value = "/one", method = RequestMethod.GET)
    public Employee getOneEmployee(String idEmployee) throws IllegalAccessException, InstantiationException {
        return new EmployeeServiceImpl().findOneEmployee(Integer.parseInt(idEmployee));
    }

    public void deleteOneEmployee(String idEmployee) {
        new EmployeeServiceImpl().deleteEmployee(Integer.parseInt(idEmployee));
    }
}
