package ro.teamnet.zth.api.em;

/**
 * Created by Diana.Diaconu on 4/21/2015.
 */
public enum RelationType {
    ONETOMANY,
    MANYTOONE
}
